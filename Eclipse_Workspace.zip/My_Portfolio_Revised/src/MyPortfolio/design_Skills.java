package MyPortfolio;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class design_Skills extends JFrame {

	private JPanel contentPane;
	//instantiation
	Strs_N_Wkns ins = new Strs_N_Wkns();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					design_Skills frame = new design_Skills();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public design_Skills() {
		setTitle("My Portfolio - Skills");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 892, 519);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btn_return = new JButton("Return");
		btn_return.setBackground(new Color(0, 0, 0));
		btn_return.setForeground(new Color(255, 255, 255));
		btn_return.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btn_return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_HomePage page = new design_HomePage();
				page.show();
				dispose();
			}
		});
		btn_return.setBounds(719, 425, 108, 28);
		btn_return.setFocusable(false);
		btn_return.setBorderPainted(false);
		contentPane.add(btn_return);
		
		JLabel lbl_design = new JLabel(ins.design);
		lbl_design.setBounds(606, 310, 211, 26);
		lbl_design.setFont(new Font("Century Gothic", Font.BOLD, 14));
		contentPane.add(lbl_design);
		
		JLabel lbl_document = new JLabel(ins.document);
		lbl_document.setBounds(606, 280, 211, 26);
		lbl_document.setFont(new Font("Century Gothic", Font.BOLD, 14));
		contentPane.add(lbl_document);
		
		JLabel lbl_write = new JLabel(ins.write);
		lbl_write.setBounds(606, 247, 211, 26);
		lbl_write.setFont(new Font("Century Gothic", Font.BOLD, 14));
		contentPane.add(lbl_write);
		
		JLabel lbl_programming = new JLabel(ins.programming);
		lbl_programming.setBounds(570, 211, 211, 26);
		lbl_programming.setFont(new Font("Century Gothic", Font.BOLD, 14));
		contentPane.add(lbl_programming);
		
		JLabel lbl_lead = new JLabel(ins.leader);
		lbl_lead.setBounds(214, 280, 211, 26);
		lbl_lead.setFont(new Font("Century Gothic", Font.BOLD, 14));
		contentPane.add(lbl_lead);
		
		JLabel lbl_emotion = new JLabel(ins.emotional);
		lbl_emotion.setBounds(174, 310, 211, 26);
		lbl_emotion.setFont(new Font("Century Gothic", Font.BOLD, 14));
		contentPane.add(lbl_emotion);
		
		JLabel lbl_self = new JLabel(ins.self);
		lbl_self.setBounds(200, 346, 211, 26);
		lbl_self.setFont(new Font("Century Gothic", Font.BOLD, 14));
		contentPane.add(lbl_self);
		
		JLabel lbl_organize = new JLabel(ins.organize);
		lbl_organize.setBounds(174, 377, 211, 26);
		lbl_organize.setFont(new Font("Century Gothic", Font.BOLD, 14));
		contentPane.add(lbl_organize);
		
		JLabel lbl_team = new JLabel(ins.teamWork);
		lbl_team.setBounds(214, 244, 211, 26);
		lbl_team.setFont(new Font("Century Gothic", Font.BOLD, 14));
		contentPane.add(lbl_team);
		
		JLabel lbl_adapt = new JLabel(ins.adapt);
		lbl_adapt.setBounds(214, 211, 211, 26);
		lbl_adapt.setFont(new Font("Century Gothic", Font.BOLD, 14));
		contentPane.add(lbl_adapt);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 878, 482);
		lblNewLabel.setIcon(new ImageIcon(design_Skills.class.getResource("/images/Skills.png")));
		contentPane.add(lblNewLabel);
	}

}
