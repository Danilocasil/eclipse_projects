package MyPortfolio;

public class Strs_N_Wkns extends Education{

	String comms = "COMMUNICATION";
	String detail = "ATTENTION TO DETAIL";
	String work = "HARD-WORKING";
	String multitask = "MULTITASKING";
	String creative = "CREATIVE";
	String resilient = "RESILIENT";
	String charisma = "CHARISMATIC";
	String overthink = "OVERTHINKING";
	String negative = "NEGATIVITY";
	String procastinate = "PROCASTINATION";
	String lowSelf = "LOW SELF-ESTEEM";
	String slowLearn = "SLOW LEARNER";
	String span = "ATTENTION SPAN";
	String speak = "PUBLIC SPEAKING";
	
}
