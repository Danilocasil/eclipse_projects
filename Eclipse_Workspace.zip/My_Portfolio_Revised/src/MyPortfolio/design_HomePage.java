package MyPortfolio;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class design_HomePage extends JFrame {

	private JPanel contentPane;
	
	public static boolean initialized;
	public static String printError;

	public static void main(String[] args) { 
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					design_HomePage frame = new design_HomePage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public design_HomePage() {
		setResizable(false);
		setTitle("Portfolio - Home Page\r\n");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 891, 512);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btn_intro = new JButton("Introduction");
		btn_intro.setBackground(new Color(0, 0, 0));
		btn_intro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_Introduction page = new design_Introduction();
				page.show();
				dispose();
			}
		});
		
		JButton btn_aboutMe = new JButton("About Me");
		btn_aboutMe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_AboutMe page = new design_AboutMe();
				page.show();
				dispose();
			}
		});
		
		JButton btn_Skills = new JButton("Skills");
		btn_Skills.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_Skills page = new design_Skills();
				page.show();
				dispose();
			}
		});
		
		JButton btn_ContactInfo = new JButton("Contact Info");
		btn_ContactInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_ContactInfo page = new design_ContactInfo();
				page.show();
				dispose();
			}
		});
		btn_ContactInfo.setForeground(Color.WHITE);
		btn_ContactInfo.setFont(new Font("Century Gothic", Font.BOLD, 13));
		btn_ContactInfo.setFocusable(false);
		btn_ContactInfo.setBorderPainted(false);
		btn_ContactInfo.setBackground(Color.BLACK);
		btn_ContactInfo.setBounds(670, 389, 129, 21);
		contentPane.add(btn_ContactInfo);
		
		JButton btn_SnW = new JButton("Strength & Weakness");
		btn_SnW.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_StrsNWkns page = new design_StrsNWkns();
				page.show();
				dispose();
			}
		});
		btn_SnW.setForeground(Color.WHITE);
		btn_SnW.setFont(new Font("Century Gothic", Font.BOLD, 9));
		btn_SnW.setFocusable(false);
		btn_SnW.setBorderPainted(false);
		btn_SnW.setBackground(Color.BLACK);
		btn_SnW.setBounds(667, 304, 132, 21);
		contentPane.add(btn_SnW);
		
		JButton btn_achievements = new JButton("Achievements");
		btn_achievements.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_Achievements page = new design_Achievements();
				page.show();
				dispose();
			}
		});
		btn_achievements.setForeground(Color.WHITE);
		btn_achievements.setFont(new Font("Century Gothic", Font.BOLD, 13));
		btn_achievements.setFocusable(false);
		btn_achievements.setBorderPainted(false);
		btn_achievements.setBackground(Color.BLACK);
		btn_achievements.setBounds(667, 220, 140, 21);
		contentPane.add(btn_achievements);
		
		JButton btn_education = new JButton("Education");
		btn_education.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_Education page = new design_Education();
				page.show();
				dispose();
			}
		});
		btn_education.setForeground(Color.WHITE);
		btn_education.setFont(new Font("Century Gothic", Font.BOLD, 14));
		btn_education.setFocusable(false);
		btn_education.setBorderPainted(false);
		btn_education.setBackground(Color.BLACK);
		btn_education.setBounds(678, 136, 121, 21);
		contentPane.add(btn_education);
		
		JButton btn_hobbies = new JButton("Hobbies");
		btn_hobbies.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_Hobbies page = new design_Hobbies();
				page.show();
				dispose();
			}
		});
		btn_hobbies.setForeground(Color.WHITE);
		btn_hobbies.setFont(new Font("Century Gothic", Font.BOLD, 14));
		btn_hobbies.setFocusable(false);
		btn_hobbies.setBorderPainted(false);
		btn_hobbies.setBackground(Color.BLACK);
		btn_hobbies.setBounds(465, 389, 121, 21);
		contentPane.add(btn_hobbies);
		btn_Skills.setForeground(Color.WHITE);
		btn_Skills.setFont(new Font("Century Gothic", Font.BOLD, 14));
		btn_Skills.setFocusable(false);
		btn_Skills.setBorderPainted(false);
		btn_Skills.setBackground(Color.BLACK);
		btn_Skills.setBounds(465, 304, 121, 21);
		contentPane.add(btn_Skills);
		btn_aboutMe.setForeground(Color.WHITE);
		btn_aboutMe.setFont(new Font("Century Gothic", Font.BOLD, 14));
		btn_aboutMe.setFocusable(false);
		btn_aboutMe.setBorderPainted(false);
		btn_aboutMe.setBackground(Color.BLACK);
		btn_aboutMe.setBounds(467, 220, 121, 21);
		contentPane.add(btn_aboutMe);
		btn_intro.setFont(new Font("Century Gothic", Font.BOLD, 14));
		btn_intro.setBounds(467, 136, 121, 21);
		btn_intro.setForeground(new Color(255, 255, 255));
		btn_intro.setFocusable(false);
		btn_intro.setBorderPainted(false);
		contentPane.add(btn_intro);
		
		JLabel lbl_HomePage = new JLabel("");
		lbl_HomePage.setBounds(0, 0, 867, 475);
		lbl_HomePage.setIcon(new ImageIcon(design_HomePage.class.getResource("/images/HomePage.png")));
		contentPane.add(lbl_HomePage);
		
	}
	
	public void initializeGUI() {
		try { // Insert Methods | Classes
			main(null);
			

			initialized = true;
		} catch (Error e) {
			initialized = false;
			String errorMessage = e.getMessage().replaceAll("Type mismatch:.*", "").trim();
			StackTraceElement errorStack = e.getStackTrace()[0];
			printError = String.format("Error in %s.%s - Syntax error at line %d: %s", errorStack.getClassName(),
					errorStack.getMethodName(), errorStack.getLineNumber(), errorMessage);
		}
	}
	}
	

