package MyPortfolio;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class design_Education extends JFrame {

	private JPanel contentPane;
	//instantiation
	Strs_N_Wkns ins = new Strs_N_Wkns();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					design_Education frame = new design_Education();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public design_Education() {
		setResizable(false);
		setTitle("My Portfolio - Education");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 896, 510);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btn_return = new JButton("Return");
		btn_return.setBackground(new Color(0, 0, 0));
		btn_return.setForeground(new Color(255, 255, 255));
		btn_return.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btn_return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_HomePage page = new design_HomePage();
				page.show();
				dispose();
			}
		});
		btn_return.setBounds(718, 423, 108, 28);
		btn_return.setFocusable(false);
		btn_return.setBorderPainted(false);
		contentPane.add(btn_return);
		
		JLabel lbl_hs = new JLabel(ins.hs);
		lbl_hs.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_hs.setBounds(256, 208, 258, 23);
		contentPane.add(lbl_hs);
		
		JLabel lbl_shs = new JLabel(ins.shs);
		lbl_shs.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_shs.setBounds(461, 330, 295, 23);
		contentPane.add(lbl_shs);
		
		JLabel lbl_college = new JLabel(ins.college);
		lbl_college.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_college.setBounds(631, 208, 230, 23);
		contentPane.add(lbl_college);
		
		JLabel lbl_elem = new JLabel(ins.elem);
		lbl_elem.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_elem.setBounds(38, 330, 289, 23);
		contentPane.add(lbl_elem);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(design_Education.class.getResource("/images/Education (1).png")));
		lblNewLabel.setBounds(0, 0, 882, 473);
		contentPane.add(lblNewLabel);
	}

}
