package MyPortfolio;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class design_Introduction extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					design_Introduction frame = new design_Introduction();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public design_Introduction() {
		setResizable(false);
		setTitle("My Portfolio - Introduction");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 891, 516);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btn_return = new JButton("Return");
		btn_return.setBackground(new Color(0, 0, 0));
		btn_return.setForeground(new Color(255, 255, 255));
		btn_return.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btn_return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_HomePage page = new design_HomePage();
				page.show();
				dispose();
			}
		});
		btn_return.setBounds(719, 425, 108, 28);
		btn_return.setFocusable(false);
		btn_return.setBorderPainted(false);
		contentPane.add(btn_return);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(0, 0, 877, 479);
		lblNewLabel.setIcon(new ImageIcon(design_Introduction.class.getResource("/images/Introduction.png")));
		contentPane.add(lblNewLabel);
	}

}
