package MyPortfolio;

public class Skills extends About_Me{

	String adapt = "ADAPTABILITY";
	String teamWork = "TEAMWORK";
	String leader = "LEADERSHIP";
	String emotional = "EMOTIONAL INTELLIGENCE";
	String self = "SELF-MOTIVATION";
	String organize = "ORGANIZATIONAL ABILITY";
	String programming = "BASIC JAVA PROGRAMMING";
	String write = "CONTENT WRITING";
	String document = "DOCUMENTATION";
	String design = "BASIC DESIGNING";
	
}
