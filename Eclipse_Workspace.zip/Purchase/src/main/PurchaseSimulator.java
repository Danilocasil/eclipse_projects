package main;

import java.util.ArrayDeque;
import java.util.Deque;
import java.text.DecimalFormat;
import java.util.Scanner;

public class PurchaseSimulator {
    static class Purchase {
        String item;
        double price;

        public Purchase(String item, double price) {
            this.item = item;
            this.price = price;
        }

        @Override
        public String toString() {
            DecimalFormat df = new DecimalFormat("0.00");
            return item + " - P" + df.format(price);
        }
    }

    public static void main(String[] args) {
        Deque<Purchase> receiptQueue = new ArrayDeque<>();
        double totalBill = 0.0;
        DecimalFormat df = new DecimalFormat("0.00");
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Receipt Generation Simulator!");

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("[1] Add Purchase");
            System.out.println("[2] Generate Receipt");
            System.out.println("[3] Display Receipt Queue");
            System.out.println("[4] Exit");

            System.out.print("Enter your choice: ");
            int choice;

            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("\nInvalid input. Please enter a valid numeric choice (1-4).");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.print("\nEnter the item name: ");
                    String itemName = scanner.nextLine();
                    System.out.print("Enter the item price: ");
                    double itemPrice;
                    try {
                        itemPrice = Double.parseDouble(scanner.nextLine());
                    } catch (NumberFormatException ex) {
                        System.out.println("\nInvalid input. Please enter a valid numeric price.");
                        continue;
                    }
                    Purchase newPurchase = new Purchase(itemName, itemPrice);
                    receiptQueue.add(newPurchase);
                    totalBill += newPurchase.price;
                    System.out.println("\nPurchase added: " + newPurchase);
                    break;
                case 2:
                    if (!receiptQueue.isEmpty()) {
                        Purchase nextPurchase = receiptQueue.poll();
                        System.out.println("\nReceipt: " + nextPurchase);
                        totalBill -= nextPurchase.price;
                    } else {
                        System.out.println("\nNo purchases in the queue.");
                    }
                    break;
                case 3:
                    if (receiptQueue.isEmpty()) {
                        System.out.println("\nReceipt Queue is empty.");
                    } else {
                        System.out.println("\nCurrent Receipt Queue:");
                        for (Purchase purchase : receiptQueue) {
                            System.out.println(purchase);
                        }
                        System.out.println("Total Bill: P" + df.format(totalBill));
                    }
                    break;
                case 4:
                    System.out.println("\nThank you for using the Receipt Generation Simulator!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("\nInvalid input. Please enter a valid choice (1-4).");
            }
        }
    }
}
