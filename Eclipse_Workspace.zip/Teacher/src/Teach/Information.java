package Teach;

public class Information extends test {
	int age = 35;
	String SubjectTeaching = "Objective Oriented Programming";
	String YearLevel = "1st Year College";
	
	void inf () {
		System.out.println("INF223");
	}

}
