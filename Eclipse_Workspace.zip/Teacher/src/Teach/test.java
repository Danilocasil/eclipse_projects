package Teach;

public class test {
	public static void main(String args[]) {
		ProgrammingTeacher obj = new ProgrammingTeacher();
		
		System.out.println(obj.teacherName);
		System.out.println(obj.designation);
		System.out.println(obj.subject);
		System.out.println(obj.department);
		System.out.println(obj.university);
		
	
		
		obj.does();
		obj.action();
		
		Information info = new Information();
		System.out.println(info.age);
		System.out.println(info.SubjectTeaching);
		System.out.println(info.YearLevel);
		
		info.inf();
		
		
	}

}
