package Teach;

class ProgrammingTeacher extends Teacher{
	String subject = "Programming";
	String department = "Computer Science";
	String teacherName = "Arnod Shortman";
	
	void action() {
		System.out.println("Program");
	}
}