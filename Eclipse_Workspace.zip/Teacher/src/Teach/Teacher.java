package Teach;

public class Teacher {
	String designation = "Teacher";
	String university = "National University";
	
	void does() {
		System.out.println("Teach");
	}
}


