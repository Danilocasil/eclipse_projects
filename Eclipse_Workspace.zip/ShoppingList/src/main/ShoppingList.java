package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ShoppingList {
    private List<ShoppingListItem> items;

    public ShoppingList() {
        this.items = new ArrayList<>();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ShoppingList myShoppingList = new ShoppingList();

        while (true) {
            System.out.println("---- My Shopping List ----");
            System.out.println("1. Add Item");
            System.out.println("2. Remove Item");
            System.out.println("3. Mark Item as Purchased");
            System.out.println("4. Display List");
            System.out.println("5. Exit");
            System.out.println("--------------------------");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter item name: ");
                    String itemName = scanner.nextLine();
                    System.out.print("Enter item description: ");
                    String itemDescription = scanner.nextLine();
                    System.out.print("Enter item price: ");
                    double itemPrice = scanner.nextDouble();
                    scanner.nextLine(); 
                    myShoppingList.addItem(itemName, itemDescription, itemPrice);
                    break;
                case 2:
                    myShoppingList.displayList();
                    System.out.print("Enter the index of the item to remove: ");
                    int removeIndex = scanner.nextInt();
                    scanner.nextLine(); 
                    myShoppingList.removeItem(removeIndex - 1);
                    break;
                case 3:
                    myShoppingList.displayList();
                    System.out.print("Enter the index of the item to mark as purchased: ");
                    int markIndex = scanner.nextInt();
                    scanner.nextLine(); 
                    myShoppingList.markItemAsPurchased(markIndex - 1); 
                    break;
                case 4:
                    myShoppingList.displayList();
                    break;
                case 5:
                    System.out.println("\nExiting program.");
                    System.exit(0);
                default:
                    System.out.println("\nInvalid choice. Please try again.");
            }
        }
    }

    public void addItem(String itemName, String itemDescription, double itemPrice) {
        ShoppingListItem newItem = new ShoppingListItem(itemName, itemDescription, itemPrice);
        items.add(newItem);
    }

    public void removeItem(int index) {
        if (index >= 0 && index < items.size()) {
            ShoppingListItem removedItem = items.remove(index);
            System.out.println("Removed item [" + (index + 1) + "] " + removedItem.itemName + " from the list.");
        } else {
            System.out.println("Invalid index. Item not removed.");
        }
    }

    public void markItemAsPurchased(int index) {
        if (index >= 0 && index < items.size()) {
            ShoppingListItem item = items.get(index);
            if (item.isPurchased()) {
                System.out.println("Item [" + (index + 1) + "] " + item.itemName + " is already marked as purchased.");
            } else {
                item.setPurchased(true);
                System.out.println("Marked item [" + (index + 1) + "] " + item.itemName + " as purchased.");
            }
        } else {
            System.out.println("Invalid index. Item not marked as purchased.");
        }
    }

    public void displayList() {
        if (items.isEmpty()) {
            System.out.println("Shopping List is empty.");
        } else {
            System.out.println("\nMy Shopping List:");
            System.out.printf("%-30s | %-40s | %s | Marked as Purchased%n", "Item name", "Item Description", "Price");

            for (int i = 0; i < items.size(); i++) {
                ShoppingListItem item = items.get(i);
                String markedStatus = item.isPurchased() ? "PURCHASED" : "NOT PURCHASED";
                System.out.printf("[%d] %-26s | %-38s | %.2f | %s%n", (i + 1), item.itemName, item.itemDescription, item.itemPrice, markedStatus);
            }
        }
    }
}

class ShoppingListItem {
    String itemName;
    String itemDescription;
    double itemPrice;
    boolean purchased;

    public ShoppingListItem(String itemName, String itemDescription, double itemPrice) {
        this.itemName = itemName;
        this.itemDescription = itemDescription;
        this.itemPrice = itemPrice;
        this.purchased = false;
    }

    public boolean isPurchased() {
        return purchased;
    }

    public void setPurchased(boolean purchased) {
        this.purchased = purchased;
    }
}
