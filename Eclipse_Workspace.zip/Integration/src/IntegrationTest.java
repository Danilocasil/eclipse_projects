import org.junit.Assert;
import org.junit.Test;

import Profile.mainprofile;
import MyPortfolio.design_HomePage;


public class IntegrationTest {

	// Collect failure messages
	public String errors = "";

	@Test
	public void test() {

		// Create instances of the main classes from the individual projects
		design_HomePage MyPortfolio = new design_HomePage(); //Carl Portfolio
		mainprofile Profile = new mainprofile(); // Danilo Portfolio
		

		// Simulate interactions and test the integration
		MyPortfolio.initializeGUI();
		Profile.initializeGUI();
	

		// Assert integration conditions
		if (!MyPortfolio.initialized) {
			errors += "\nMy Portfolio can't be configure \n" + MyPortfolio.printError + "\n";
		}
		if (!Profile.initialized) {
			errors += "\nProfile can't be configure\n" + Profile.printError + "\n";
		}
		

		
		if (errors.length() > 0) {
			Assert.fail(errors);
		} else {
			System.out.print("All programs are working");
		}
	}
}
