package Inheritance;

public class Vehicles {
	int speed;
	String color;
	int price;
	
	void stop() {
		System.out.println("The Vehicle has stopped");
	}
	
}



