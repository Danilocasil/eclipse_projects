package Profile;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.PseudoColumnUsage;
import java.awt.Font;

public class aboutme extends JFrame {
	
//	Instantiation ng subclass lahat ng nakainherited na variables from subclasss to parent class
	personality pers = new personality();

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					aboutme frame = new aboutme();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public aboutme() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1239, 724);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel Aboutme = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/Aboutme.png")).getImage();
		Image img2 = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		
		final JLabel back = new JLabel("");
		back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			mainprofile mp = new mainprofile();
			mp.setVisible(true);
			mp.setLocationRelativeTo(null);
			dispose();
		}
		});
//		dinidisplay ung inherited variables 
		JLabel hair = new JLabel(pers.hair);
		hair.setForeground(Color.WHITE);
		hair.setFont(new Font("Constantia", Font.BOLD, 30));
		hair.setBounds(725, 575, 86, 50);
		contentPane.add(hair);
		
		JLabel specialization = new JLabel(pers.specialization);
		specialization.setForeground(Color.WHITE);
		specialization.setFont(new Font("Constantia", Font.BOLD, 27));
		specialization.setBounds(634, 527, 418, 50);
		contentPane.add(specialization);
		
		JLabel course = new JLabel(pers.course);
		course.setForeground(Color.WHITE);
		course.setFont(new Font("Constantia", Font.BOLD, 30));
		course.setBounds(762, 488, 275, 50);
		contentPane.add(course);
		
		JLabel school = new JLabel(pers.school);
		school.setForeground(Color.WHITE);
		school.setFont(new Font("Constantia", Font.BOLD, 30));
		school.setBounds(762, 403, 290, 50);
		contentPane.add(school);
		
		JLabel age = new JLabel(pers.age);
		age.setForeground(Color.WHITE);
		age.setFont(new Font("Constantia", Font.BOLD, 35));
		age.setBounds(725, 319, 45, 50);
		contentPane.add(age);
		
		JLabel birthday = new JLabel(pers.birthday);
		birthday.setForeground(Color.WHITE);
		birthday.setFont(new Font("Constantia", Font.BOLD, 28));
		birthday.setBounds(793, 237, 258, 50);
		contentPane.add(birthday);
		
		JLabel sex = new JLabel(pers.sex);
		sex.setForeground(Color.WHITE);
		sex.setFont(new Font("Constantia", Font.BOLD, 30));
		sex.setBounds(727, 158, 86, 40);
		contentPane.add(sex);
		
		JLabel name = new JLabel(pers.name);
		name.setFont(new Font("Constantia", Font.BOLD, 30));
		name.setForeground(Color.WHITE);
		name.setBounds(746, 71, 290, 50);
		contentPane.add(name);
		
		JLabel mindful = new JLabel(pers.mindful);
		mindful.setForeground(Color.WHITE);
		mindful.setFont(new Font("Segoe UI Black", Font.PLAIN, 35));
		mindful.setBounds(325, 454, 156, 40);
		contentPane.add(mindful);
		
		JLabel introvert = new JLabel(pers.introvert);
		introvert.setForeground(Color.WHITE);
		introvert.setFont(new Font("Segoe UI Black", Font.PLAIN, 35));
		introvert.setBounds(99, 403, 179, 40);
		contentPane.add(introvert);
		
		JLabel flexible = new JLabel(pers.flexible);
		flexible.setForeground(Color.WHITE);
		flexible.setFont(new Font("Segoe UI Black", Font.PLAIN, 35));
		flexible.setBounds(99, 555, 156, 40);
		contentPane.add(flexible);
		
		JLabel dependable = new JLabel(pers.depedable);
		dependable.setForeground(Color.WHITE);
		dependable.setFont(new Font("Segoe UI Black", Font.PLAIN, 35));
		dependable.setBounds(99, 504, 221, 40);
		contentPane.add(dependable);
		
		JLabel creative = new JLabel(pers.creative);
		creative.setForeground(Color.WHITE);
		creative.setFont(new Font("Segoe UI Black", Font.PLAIN, 35));
		creative.setBounds(99, 454, 168, 40);
		contentPane.add(creative);
		
		JLabel calm = new JLabel(pers.calm);
		calm.setFont(new Font("Segoe UI Black", Font.PLAIN, 35));
		calm.setForeground(Color.WHITE);
		calm.setBounds(325, 403, 156, 40);
		contentPane.add(calm);
		back.setBounds(10, 11, 135, 50);
		contentPane.add(back);
		
		back.setIcon(new ImageIcon(img2));
		Aboutme.setIcon(new ImageIcon(img));
		Aboutme.setBounds(0, 0, 1230, 693);
		contentPane.add(Aboutme);
	}
}
