package Profile;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class hobbies extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					hobbies frame = new hobbies();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public hobbies() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1239, 724);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel hobbies = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/Hobbies.png")).getImage();
		Image img2 = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		
		JLabel hobby = new JLabel("");
		hobby.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				mainprofile mp = new mainprofile();
				mp.setVisible(true);
				mp.setLocationRelativeTo(null);
				dispose();
			}
		});
		hobby.setBounds(10, 11, 135, 50);
		hobby.setIcon(new ImageIcon(img2));
		contentPane.add(hobby);
		hobbies.setIcon(new ImageIcon(img));
		hobbies.setBounds(0, 0, 1230, 693);
		contentPane.add(hobbies);
	}

}
