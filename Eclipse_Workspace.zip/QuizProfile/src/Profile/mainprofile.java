package Profile;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class mainprofile extends JFrame {

	private JPanel contentPane;
	
	public static boolean initialized;
	public static String printError;
	
    
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainprofile frame = new mainprofile();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public mainprofile() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1239, 724);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel mainpage = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/Main.png")).getImage();
		
		final JButton achievementandtalent = new JButton("Achievements & Talents");
		achievementandtalent.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				achievementsandtalents act = new achievementsandtalents();
				act.setVisible(true);
				act.setLocationRelativeTo(null);
				dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			achievementandtalent.setForeground(Color.DARK_GRAY);
			}
			@Override
			public void mouseExited(MouseEvent e) {
			achievementandtalent.setForeground(Color.WHITE);
			}
		});
		achievementandtalent.setForeground(new Color(255, 250, 250));
		achievementandtalent.setFocusPainted(false);
		achievementandtalent.setOpaque(false);
		achievementandtalent.setContentAreaFilled(false);
		achievementandtalent.setBorderPainted(false);
		achievementandtalent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		
		final JButton skills = new JButton("Skills");
		skills.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				skills sk = new skills();
				sk.setVisible(true);
				sk.setLocationRelativeTo(null);
				dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				skills.setForeground(Color.DARK_GRAY);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				skills.setForeground(Color.WHITE);
			}
		});
		skills.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		JLabel back = new JLabel("");
		back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		Image img2 = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		back.setIcon(new ImageIcon(img2));
		back.setBounds(10, 11, 135, 50);
		contentPane.add(back);
		skills.setForeground(new Color(255, 250, 250));
		skills.setFont(new Font("Segoe UI Black", Font.BOLD, 55));
		skills.setBounds(740, 75, 190, 64);
		skills.setFocusPainted(false);
		skills.setOpaque(false);
		skills.setContentAreaFilled(false);
		skills.setBorderPainted(false);
		contentPane.add(skills);
		
		final JButton hobbies = new JButton("Hobbies");
		hobbies.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hobbies hobi = new hobbies();
				hobi.setVisible(true);
				hobi.setLocationRelativeTo(null);
				dispose();
		}
			@Override
			public void mouseEntered(MouseEvent e) {
				hobbies.setForeground(Color.DARK_GRAY);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				hobbies.setForeground(Color.WHITE);
			}
		});
		hobbies.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		hobbies.setForeground(new Color(255, 250, 250));
		hobbies.setFont(new Font("Segoe UI Black", Font.BOLD, 55));
		hobbies.setBounds(700, 237, 275, 64);
		hobbies.setFocusPainted(false);
		hobbies.setOpaque(false);
		hobbies.setContentAreaFilled(false);
		hobbies.setBorderPainted(false);
		contentPane.add(hobbies);
		achievementandtalent.setFont(new Font("Segoe UI Black", Font.BOLD, 55));
		achievementandtalent.setBounds(460, 380, 737, 64);
		contentPane.add(achievementandtalent);
		
		final JButton aboutme = new JButton("About Me");
		aboutme.setForeground(new Color(255, 250, 250));
		aboutme.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				aboutme ab = new aboutme();
				ab.setVisible(true);
				ab.setLocationRelativeTo(null);
				dispose();
			}
//			changed color when the mouse entering 
			@Override
			public void mouseEntered(MouseEvent e) {
				aboutme.setForeground(Color.DARK_GRAY);
			}
			@Override
//			going back from the original color when exiting from the Jbutton
			public void mouseExited(MouseEvent e) {
				aboutme.setForeground(Color.WHITE);
			}
		});
		aboutme.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		aboutme.setFont(new Font("Segoe UI Black", Font.BOLD, 55));
		aboutme.setBounds(670, 520, 319, 64);
		aboutme.setFocusPainted(false);
		aboutme.setOpaque(false);
		aboutme.setContentAreaFilled(false);
		aboutme.setBorderPainted(false);
		contentPane.add(aboutme);
		mainpage.setIcon(new ImageIcon(img));
		mainpage.setBounds(0, 0, 1230, 693);
		contentPane.add(mainpage);
	}
	
	public void initializeGUI() {
		try { // Insert Methods | Classes
			main(null);
			

			initialized = true;
		} catch (Error e) {
			initialized = false;
			String errorMessage = e.getMessage().replaceAll("Type mismatch:.*", "").trim();
			StackTraceElement errorStack = e.getStackTrace()[0];
			printError = String.format("Error in %s.%s - Syntax error at line %d: %s", errorStack.getClassName(),
					errorStack.getMethodName(), errorStack.getLineNumber(), errorMessage);
		}
	}
	}