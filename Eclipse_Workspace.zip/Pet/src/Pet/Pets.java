package Pet;

public class Pets {
	
	public static void main(String[] args) {
		Pusa pusa = new Pusa();
		pusa.color = "blue";
		pusa.age = 1;
		
		pusa.meow();
		pusa.eat();
		
		Aso aso = new Aso();
		aso.color = "black";
		aso.breed = "hasky";
		
		aso.bark();
		aso.eat();
		
		
	}

}
