package Pet;

public class Animal {
	String color;
	
	public void eat() {
		System.out.println("They can eat");
	}

}
