package Pet;

public class Pusa extends Animal{
	int age;
	
	public void meow() {

}
}
