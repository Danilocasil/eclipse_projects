package Pet;

public class Aso extends Animal {
String breed;

public void bark() {
}
}