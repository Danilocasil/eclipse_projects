package AbstractionAndDataCollection;

import java.util.Scanner;
import java.text.DecimalFormat;

public class StudentGrades {
    private double[] studentGrades; // Array to store student grades

    // Constructor to initialize studentGrades array
    public StudentGrades(double[] grades) {
        this.studentGrades = grades;
    }

    // Method to calculate and print the average grade
    public void averageGrade() {
        double sum = 0;
        int numGrades = studentGrades.length;

        for (int i = 0; i < numGrades; i++) {
            sum += studentGrades[i];
        }

        // Calculate the average grade
        double average = sum / numGrades;

        // Create a DecimalFormat object to format the average to two decimal places
        DecimalFormat decimalFormat = new DecimalFormat("#.##");

        // Format the average
        String formattedAverage = decimalFormat.format(average);

        // Print the formatted average
        System.out.println("Average Grade: " + formattedAverage);
    }

    // Method to calculate and print the maximum grade
    public void maxGrade() {
        double max = studentGrades[0]; // Assume the first grade is the maximum

        for (int i = 1; i < studentGrades.length; i++) {
            if (studentGrades[i] > max) {
                max = studentGrades[i];
            }
        }

        // Print the maximum grade
        System.out.println("Maximum Grade: " + max);
    }

    // Method to calculate and print the minimum grade
    public void minGrade() {
        double min = studentGrades[0]; // Assume the first grade is the minimum

        for (int i = 1; i < studentGrades.length; i++) {
            if (studentGrades[i] < min) {
                min = studentGrades[i];
            }
        }

        // Print the minimum grade
        System.out.println("Minimum Grade: " + min);
    }

    // Method to display individual grades
    public void displayGrades() {
        System.out.println("Student Grades:");

        for (int i = 0; i < studentGrades.length; i++) {
            System.out.println(studentGrades[i]);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of students: ");
        int numStudents = scanner.nextInt();
        
        double[] studentGrades = new double[numStudents]; // Create an array to store student grades

        System.out.println("Enter " + numStudents + " student's grades:"); // Prompt the user for input

        // Read and store the grades in the array
        for (int i = 0; i < numStudents; i++) {
            studentGrades[i] = scanner.nextDouble();
        }

        // Create an instance of the StudentGrades class
        StudentGrades student = new StudentGrades(studentGrades);

        // Call various methods to display and analyze grades
        student.displayGrades(); // Printing all grades
        student.averageGrade();  // Calculate and print the average grade
        student.maxGrade();      // Calculate and print the maximum grade
        student.minGrade();      // Calculate and print the minimum grade

        scanner.close(); // Close the Scanner
    }
}
